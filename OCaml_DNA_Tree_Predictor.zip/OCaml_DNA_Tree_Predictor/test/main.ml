open OUnit2
open Helices
open Dna

(******************************************************************************)
(********************** REMEMBER TO WRITE TESTS FIRST! ************************)
(******************************************************************************)

(* Pretty printers for OUnit messages. These print values mostly like the
   toplevel prints them. *)

let pp_pair pp_l pp_r (l, r) = Printf.sprintf "(%s, %s)" (pp_l l) (pp_r r)

let pp_list pp_elt lst =
  let pp_elts lst =
    let rec loop n acc = function
      | [] -> acc
      | [ h ] -> acc ^ pp_elt h
      | h1 :: (h2 :: t as t') ->
          if n = 100 then acc ^ "..." (* stop printing long list *)
          else loop (n + 1) (acc ^ pp_elt h1 ^ "; ") t'
    in
    loop 0 "" lst
  in
  Printf.sprintf "[%s]" (pp_elts lst)

let pp_helix = pp_list string_of_nucleotide
let pp_helix_list = pp_list pp_helix
let pp_acid_list = pp_list string_of_acid
let pp_acid_list_list = pp_list pp_acid_list

let pp_tree t =
  let rec f ws t =
    let ews = ws ^ "    " in
    match t with
    | Leaf h -> ws ^ "Leaf " ^ pp_helix h
    | Node (l, r) ->
        ws ^ "Node (\n" ^ f ews l ^ ",\n" ^ f ews r ^ "\n" ^ ws ^ ")"
  in
  "\n" ^ f "" t

let pp_ltree t =
  let rec f ws t =
    let ews = ws ^ "    " in
    match t with
    | LLeaf h -> ws ^ "LLeaf " ^ pp_helix h
    | LNode (l, h, r) ->
        ws ^ "LNode (\n" ^ f ews l ^ ",\n" ^ ews ^ pp_helix h ^ ",\n" ^ f ews r
        ^ "\n" ^ ws ^ ")"
  in
  "\n" ^ f "" t

let pp_ltree_list = pp_list pp_ltree
let pp_ltree_int_pair = pp_pair pp_ltree string_of_int

(************************ complementary_helix tests ***************************)

let complementary_helix_test out in1 _ =
  assert_equal ~printer:pp_helix
    ~msg:("function: complementary_helix\ninput: " ^ pp_helix in1)
    out
    (Dna.complementary_helix in1)

let complementary_helix_tests =
  [
    "complementary_helix multi-element list"
    >:: complementary_helix_test [ G; A; A; G ] [ C; T; T; C ];
     
    "complementary_helix empty list"
    >:: complementary_helix_test [] [];

    "complementary_helix single element list"
    >:: complementary_helix_test [G] [C];

    "another complementary_helix multi element list"
    >:: complementary_helix_test [A; G; T; C; T; A] [T; C; A; G; A; T];

    "complementary_helix multi element list with the same nucleotide"
    >:: complementary_helix_test [A; A; A; A; A] [T; T; T; T; T];

    "another complementary_helix multi element list"
    >:: complementary_helix_test [G; A; T; T; C; A] [C; T; A; A; G; T];
  
  ]
   

 

(*************************** hamming_distance tests ***************************)

let hamming_distance_test out in1 in2 _ =
  assert_equal ~printer:string_of_int
    ~msg:
      (Printf.sprintf "function: hamming_distance\ninputs: %s %s" (pp_helix in1)
         (pp_helix in2))
    out
    (Dna.hamming_distance in1 in2)

let hamming_invalid_arg_test in1 in2 _ =
  let exn = Invalid_argument "..." in
  assert_raises
    ~msg:
      (Printf.sprintf "function: hamming_distance\ninput: %s %s" (pp_helix in1)
         (pp_helix in2))
    exn
    (fun () ->
      try Dna.hamming_distance in1 in2 with Invalid_argument _ -> raise exn)

let hamming_distance_tests =
  [ (* Example test cases: *)
    "hamming_distance empty" >:: hamming_distance_test 0 [] [];
    
    "hamming_distance one different nucleotide" >:: hamming_distance_test 1 [
       G; A ] [ G; T ]; 
    
    "hamming_distance nonmatching lengths" >:: hamming_invalid_arg_test [ C ]
       []; 
    
    "hamming_distance one differing nucleotide for longer helices" >:: 
    hamming_distance_test 1 [G; G; A; A; T; T; G; A; C; A; A ] [G; G; A; A; T; T; G; A; C; C; A ];

    "hamming_distance two differing nucleotides for shorter helices" >::
    hamming_distance_test 2 [G; A; T; T ] [G; T; C; T ]; 

    "hamming_distance two differing nucleotides for longer helices" >::
    hamming_distance_test 2 [G; A; A; G; T; A; C; C; A; T; A ] [G; A; T; G; T; A; G; C; A; T; A ];   

    "hamming_distance unmatching lengths for longer lists" >::
    hamming_invalid_arg_test [A; T; G; C; T; C; A; A; C; A; T; A; A; A ] [A; T; G; C; T; C; A; A; C; A; T; A; A ]; 

    "hamming_distance no differing nucleotide" >:: hamming_distance_test 0 [A; T; C; G; G; C; T; T ] [A; T; C; G; G; C; T; T ]; 

    "hamming_distance every nucleotide is diff" >:: hamming_distance_test 6 [A; G; C; T; C; A ] [G; C; T; C; A; G ]; 
       ]


(************************ decreasing_similarity tests *************************)

let decreasing_similarity_test out in1 _ =
  assert_equal ~printer:string_of_bool
    ~msg:("function: decreasing_similarity\ninput: " ^ pp_helix_list in1)
    out
    (Dna.decreasing_similarity in1)

let decreasing_similarity_tests =
  [ (* Example test case: *)
    "decreasing_similarity to humans" >:: decreasing_similarity_test true
       (Dna.most_like_human ());]

(***************************** count_leaves tests *****************************)

let count_leaves_test out in1 _ =
  assert_equal ~printer:string_of_int
    ~msg:("function: count_leaves\ninput: " ^ pp_tree in1)
    out (Dna.count_leaves in1)

let count_leaves_tests = [
  (*Test cases for count_leaves_tests*)
 "count_leaves one leaf tree" >:: count_leaves_test 1 (Leaf white_cheeked_gibbon);
  "count_leaves tree with only leaves" >:: count_leaves_test 2 (Node(Leaf white_cheeked_gibbon, Leaf orangutan));
  "count_leaves tree with one subtree (node) inside" >:: count_leaves_test 3 (Node(Leaf orangutan, Node(Leaf siamang, Leaf chimpanzee)));
  "count_leaves tree multiple subtrees" >:: count_leaves_test 4 (lesser_apes());
  "count_leaves another tree with multiple subtrees - more subtrees than last one" >:: count_leaves_test 5 (Node(Leaf orangutan, Node(Leaf siamang, Node(Leaf human, Node(Leaf lar_gibbon, Leaf gorilla)))));
]

(**************************** helix_of_tree tests *****************************)

let helix_of_tree_test out in1 _ =
  assert_equal ~printer:pp_helix
    ~msg:("function: helix_of_tree\ninput: " ^ pp_ltree in1)
    out (Dna.helix_of_tree in1)

let helix_of_tree_tests = [
  (*Test cases for helix_of_tree*)
  "helix_of_tree one Leaf only" >:: helix_of_tree_test chimpanzee (LLeaf chimpanzee);
  "helix_of_tree one root, two leaves" >:: helix_of_tree_test chimpanzee (LNode(LLeaf gorilla, chimpanzee, LLeaf pileated_gibbon));
  "helix_of_tree tree with one subtrees" >:: helix_of_tree_test gorilla (LNode(LNode(LLeaf pileated_gibbon, lar_gibbon, LLeaf human), gorilla, LLeaf chimpanzee));
  "helix_of_tree tree with two subtrees" >:: helix_of_tree_test lar_gibbon (LNode(LNode(LLeaf pileated_gibbon, chimpanzee, LLeaf gorilla), lar_gibbon, LNode(LLeaf white_cheeked_gibbon, siamang, LLeaf human)));
  "helix_of_tree tree with three subtrees" >:: helix_of_tree_test chimpanzee (LNode(LNode(LLeaf siamang, lar_gibbon, LLeaf white_cheeked_gibbon), chimpanzee, LNode(LNode(LLeaf human, pileated_gibbon, LLeaf orangutan), gorilla, LLeaf human)));
]

(**************************** unlabel_tree tests ******************************)

let unlabel_tree_test out in1 _ =
  assert_equal ~printer:pp_tree
    ~msg:("function: unlabel_tree\ninput: " ^ pp_ltree in1)
    out (Dna.unlabel_tree in1)

let unlabel_tree_tests = [
  (*Test cases for unlabel_tree*)
  "unlabel_tree one Leaf only" >:: unlabel_tree_test (Leaf chimpanzee) (LLeaf chimpanzee);
  "unlabel_tree one root, 2 leaves" >:: unlabel_tree_test (Node(Leaf gorilla, Leaf pileated_gibbon)) (LNode(LLeaf gorilla, chimpanzee, LLeaf pileated_gibbon));
  "unlabel_tree tree with one subtree" >:: unlabel_tree_test (Node(Node(Leaf pileated_gibbon, Leaf human), Leaf chimpanzee)) (LNode(LNode(LLeaf pileated_gibbon, lar_gibbon, LLeaf human), gorilla, LLeaf chimpanzee));
  "unlabel_tree tree with two subtrees" >:: unlabel_tree_test (Node(Node(Leaf pileated_gibbon, Leaf gorilla), Node(Leaf white_cheeked_gibbon, Leaf human))) (LNode(LNode(LLeaf pileated_gibbon, chimpanzee, LLeaf gorilla), lar_gibbon, LNode(LLeaf white_cheeked_gibbon, siamang, LLeaf human)));
  "unlabel_tree tree with three subtrees" >:: unlabel_tree_test (Node(Node(Leaf siamang, Leaf white_cheeked_gibbon), Node(Node(Leaf human, Leaf orangutan), Leaf human))) (LNode(LNode(LLeaf siamang, lar_gibbon, LLeaf white_cheeked_gibbon), chimpanzee, LNode(LNode(LLeaf human, pileated_gibbon, LLeaf orangutan), gorilla, LLeaf human)));
]

(************************* guess_parent_helix tests ***************************)

let guess_parent_helix_test out in1 in2 _ =
  assert_equal ~printer:pp_helix
    ~msg:
      (Printf.sprintf "function: guess_parent_helix\ninputs: %s %s"
         (pp_helix in1) (pp_helix in2))
    out
    (Dna.guess_parent_helix in1 in2)

let guess_invalid_arg_test in1 in2 _ =
  let exn = Invalid_argument "..." in
  assert_raises
    ~msg:
      (Printf.sprintf "function: guess_parent_helix\ninput: %s %s"
         (pp_helix in1) (pp_helix in2))
    exn
    (fun () ->
      try Dna.guess_parent_helix in1 in2 with Invalid_argument _ -> raise exn)

let guess_parent_helix_tests =
  [ (* Example test case: *)
     "guess_parent_helix one difference" >:: guess_parent_helix_test [ G; C; A
       ] [ T; C; A ] [ G; C; A ];
       "guess_parent_helix empty helices" >:: guess_parent_helix_test [] [] [];
       "guess_parent_helix no differences" >:: guess_parent_helix_test [G; G; G] [G; G; G] [G; G; G ];
       "guess_parent_helix unequal helices" >:: guess_invalid_arg_test [A; T; G; C; A; G] [G; A; A; A ];
       "guess_parent_helix different for each nucleotide" >:: guess_parent_helix_test [A; G; A; T] [A; G; A; T] [G; T; T; A];
       "guess_parent_helix first nucleotide is the same, the rest are different" >:: guess_parent_helix_test [A; A; T; T] [A; A; T; T ] [A; T; G; C];
       "guess_parent_helix first 3 nucleotides are the same, the rest are different" >:: guess_parent_helix_test [A; A; A; G; T; T] [A; A; A; G; T; T] [A; A; A; T; A; A];
       "guess_parent_helix compare two different 1-nucleotide helices" >:: guess_parent_helix_test [A] [A] [G];
       ]

(************************ add_ancestor_labels tests ***************************)

let add_ancestor_labels_test out in1 _ =
  assert_equal ~printer:pp_ltree
    ~msg:("function: add_ancestor_labels\ninput: " ^ pp_tree in1)
    out
    (Dna.add_ancestor_labels in1)

let add_ancestor_labels_tests =
  [ (* Example test case: *)
    "add_ancestor_labels leaf" >:: add_ancestor_labels_test (LLeaf [ T; C ])
       (Leaf [ T; C ]);
    "add_ancestor_labels tree with just 2 leaves" >:: add_ancestor_labels_test 
    (LNode(LLeaf [A; A; T], [A; A; T], LLeaf [G; A; C])) (Node(Leaf [A; A; T], Leaf [G; A; C]));
     "add_ancestor_labels tree with 1 subtree" >:: add_ancestor_labels_test 
     (LNode(LNode(LLeaf [A; G; A; G], [A; G; A; G], LLeaf [T; G; A; C]), [A; G; A; G], LLeaf [A; T; T; T])) (Node(Node(Leaf [A; G; A; G], Leaf [T; G; A; C]), Leaf [A; T; T; T]));
     "add_ancestor_labels tree with two subtrees" >:: add_ancestor_labels_test 
     (LNode(LNode(LLeaf [G; A; T; T], [G; A; T; T], LLeaf [T; G; T; T]), [A; C; C; T], 
     LNode(LLeaf [A; C; C; T], [A; C; C; T], LLeaf [G; C; A; A]))) (Node(Node(Leaf [G; A; T; T], Leaf [T; G; T; T]), Node(Leaf [A; C; C; T], Leaf [G; C; A; A])));
     "add_ancestor_labels tree with three subtrees (3 EMBEDDED NODES)" >:: add_ancestor_labels_test 
     (LNode(LNode(LLeaf [A; A; C; C],[A; A; C; C], LLeaf [C; A; T; T]), [A; A; C; C], 
     LNode(LNode(LLeaf [C; C; A; T],[C; C; A; T], LLeaf [G; G; A; A]), [C; C; A; T], LLeaf [T; A; A; G]))) (Node(Node(Leaf [A; A; C; C], Leaf [C; A; T; T]), Node(Node(Leaf [C; C; A; T], Leaf [G; G; A; A]), Leaf [T; A; A; G])));
     "add_ancestor_labels tree with four subtrees (4 EMBEDDED NODES)" >:: add_ancestor_labels_test 
     (LNode(LNode(LNode(LLeaf [A; T; C; C], [A; T; C; C], LLeaf [A; T; G; G]), [A; C; C; T], LNode(LLeaf [A; C; C; T], [A; C; C; T], 
     LLeaf [A; G; G; G])),[A; C; C; T], LNode(LLeaf [T; G; A; A], [C; A; A; T], LLeaf [C; A; A; T]))) (Node(Node(Node(Leaf [A; T; C; C], Leaf [A; T; G; G]), Node(Leaf [A; C; C; T], Leaf [A; G; G; G])), Node(Leaf [T; G; A; A], Leaf [C; A; A; T]))); 
       ]

(************************ parent_child_hamming tests **************************)

(* Be sure to test for trees of depth greater than one. *)

let parent_child_hamming_test out in1 _ =
  assert_equal ~printer:string_of_int
    ~msg:("function: parent_child_hamming\ninput: " ^ pp_ltree in1)
    out
    (Dna.parent_child_hamming in1)

let parent_child_hamming_tests =
  [ (* Example test case: *)
    "parent_child_hamming depth-2 tree, all different" >::
       parent_child_hamming_test 2 (LNode (LLeaf [ T ], [ A ], LLeaf [ G ])); 
    "parent_child_hamming depth-2 tree, all the same" >:: parent_child_hamming_test 0 
    (LNode(LLeaf [T; A; A], [T; A; A], LLeaf [T; A; A]));
    "parent_child_hamming depth-2 tree, one pair is the same, one pair is different" >:: parent_child_hamming_test 2 
    (LNode(LLeaf [T; A; A], [T; A; A], LLeaf [G; T; A]));
    "parent_child_hamming depth-3 tree, extended both sides fully" >:: parent_child_hamming_test 7 
    (LNode(LNode(LLeaf [T; T], [T; G], LLeaf [C; C]), [A; G], LNode(LLeaf [C; T], [C; G], LLeaf [C; A])));
    "parent_child_hamming depth-4 tree, extended one side fully" >:: parent_child_hamming_test 9 (LNode(LNode(LLeaf [T; T], [T; G], LLeaf [C; C]), [A; G], LNode(LNode(LLeaf [A; T], [C; T], LLeaf [T; T]), [C; G], LLeaf [C; A])));
    "parent_child_hamming depth-4 tree, extended one side fully again" >:: parent_child_hamming_test 9 (LNode(LNode(LNode(LLeaf [G; T], [T; T], LLeaf [T; C]), [T; G], LLeaf [C; C]), [A; G], LNode(LLeaf [C; T], [C; G], LLeaf [C; A])));
    "parent_child_hamming depth-5 tree, extended one side fully " >:: parent_child_hamming_test 14 (LNode(LNode(LNode(LLeaf [G; T], [T; T], LLeaf [T; C]), [T; G], LLeaf [C; C]), [A; G], LNode(LNode(LNode(LLeaf [A; A], [A; T], LLeaf [T; A]), [C; T], LLeaf [T; T]), [C; G], LLeaf [C; A])));
    "parent_child hamming leaf" >:: parent_child_hamming_test 0 (LLeaf [T; A; A]);  
        ]

(**************************** simplest_tree tests *****************************)

let t1 = Dna.LNode (Dna.LLeaf [ A ], [ T ], Dna.LLeaf [ C ])

let t2 =
  Dna.LNode
    ( Dna.LLeaf [ G; T ],
      [ A; T ],
      Dna.LNode (Dna.LLeaf [ T; T ], [ T; T ], Dna.LLeaf [ C; G ]) )
    
(*tree1 => 0, tree2 => 2, tree3 => 7, tree4 => 9, tree5 => 9, tree6 => 14*)
let tree1 = LNode(LLeaf [T; A; A], [T; A; A], LLeaf [T; A; A])
let tree11 = LNode(LLeaf [A; C; A], [A; C; A], LLeaf [A; C; A])
let tree2 =LNode(LLeaf [T; A; A], [T; A; A], LLeaf [G; T; A])
let tree3 = LNode(LNode(LLeaf [T; T], [T; G], LLeaf [C; C]), [A; G], 
LNode(LLeaf [C; T], [C; G], LLeaf [C; A]))
let tree4 = LNode(LNode(LLeaf [T; T], [T; G], LLeaf [C; C]), [A; G], 
LNode(LNode(LLeaf [A; T], [C; T], LLeaf [T; T]), [C; G], LLeaf [C; A]))
let tree5 =LNode(LNode(LNode(LLeaf [G; T], [T; T], LLeaf [T; C]), [T; G], 
LLeaf [C; C]), [A; G], LNode(LLeaf [C; T], [C; G], LLeaf [C; A]))
let tree6 = LNode(LNode(LNode(LLeaf [G; T], [T; T], LLeaf [T; C]), [T; G], 
LLeaf [C; C]), [A; G], LNode(LNode(LNode(LLeaf [A; A], [A; T], LLeaf [T; A]), 
[C; T], LLeaf [T; T]), [C; G], LLeaf [C; A]))
let leaf1= LLeaf [T; A; A]

let simplest_tree_test out in1 _ =
  assert_equal ~printer:pp_ltree_int_pair
    ~msg:("function: simplest_tree\ninput: " ^ pp_ltree_list in1)
    out (Dna.simplest_tree in1)

let simplest_tree_invalid_arg_test in1 _ =
  let exn = Invalid_argument "..." in
  assert_raises
    ~msg:(Printf.sprintf "function: simplest_tree\ninput: " ^ pp_ltree_list in1)
    exn
    (fun () -> try Dna.simplest_tree in1 with Invalid_argument _ -> raise exn)

let simplest_tree_tests =
  [ (* Example test case: *)
    "simplest_tree two tree list" >:: simplest_tree_test (t1, 2) [ t1; t2 ]; 
    "simplest_tree empty list" >:: simplest_tree_invalid_arg_test [];
    "simplest_tree equal cases for two tree list" >:: simplest_tree_test 
    (tree4, 9) [tree4; tree5];
    "simplest_tree contains equal cases for six tree list" >:: simplest_tree_test 
    (tree11, 0) [tree4; tree5; tree3; tree11; tree1; tree2];
    "simplest_tree contains equal cases for five tree list in separate spots, one tree at start and 
    one at the end of the list" >:: simplest_tree_test (tree1, 0) [tree1; tree2; tree6; tree3; tree11];
    "simplest_tree four tree list" >:: simplest_tree_test (tree2, 2) [tree3; tree4; tree6; tree2];
    "simplest_tree one tree list" >:: simplest_tree_test (tree3, 7) [tree3];
     ]

(********************* find_simplest_tree tests ************************)

let find_simplest_tree_test out in1 in2 in3 in4 _ =
  assert_equal ~printer:pp_tree
    ~msg:
      (Printf.sprintf "function: find_simplest_tree\ninputs: %s %s %s %s"
         (pp_helix in1) (pp_helix in2) (pp_helix in3) (pp_helix in4))
    out
    (Dna.find_simplest_tree in1 in2 in3 in4)

let find_simplest_invalid_arg_test in1 in2 in3 in4 _ =
  let exn = Invalid_argument "..." in
  assert_raises
    ~msg:
      (Printf.sprintf "function: find_simplest_tree\ninputs: %s %s %s %s"
         (pp_helix in1) (pp_helix in2) (pp_helix in3) (pp_helix in4))
    exn
    (fun () ->
      try Dna.find_simplest_tree in1 in2 in3 in4
      with Invalid_argument _ -> raise exn)

let helix1 = [A; T]
let helix2 = [T; A]
let helix3 = [T; T]
let helix4 = [A; T]
let find_simplest_tree_tests =
  [ (* Example test case: *)
    "simplest_greater_ape_tree" >:: find_simplest_tree_test
       (Dna.simplest_greater_ape_tree ()) gorilla human chimpanzee orangutan; 
    "simplest lesser_ape_tree" >:: find_simplest_tree_test 
    (Dna.simplest_lesser_ape_tree()) pileated_gibbon lar_gibbon siamang white_cheeked_gibbon;
    "simplest_tree same helices" >:: find_simplest_tree_test 
    (Node(Node(Leaf [T; T], Leaf [T; T]), Node(Leaf [T; T], Leaf [T; T]))) helix3 helix3 helix3 helix3;
    "simplest_tree shorter helices - all different" >:: find_simplest_tree_test 
    (Node(Node(Leaf [A; T], Leaf [T; A]), Node(Leaf [T; T], Leaf [A; T]))) helix1 helix2 helix3 helix4;
    "simplest_tree shorter helices- two are the same ">:: find_simplest_tree_test 
    (Node(Node(Leaf [A; T], Leaf [A; T]), Node(Leaf [T; A], Leaf [T; T]))) helix1 helix1 helix2 helix3;
    "simplest_tree shorter helices - three are different">:: find_simplest_tree_test 
    (Node(Node(Leaf [A; T], Leaf [A; T]), Node(Leaf [T; A], Leaf [T; T]))) helix1 helix1 helix2 helix3;
    ]

(**************************** acids_of_helix tests ****************************)
(*let tac_list_test out in1 _ =
  assert_equal ~printer:pp_helix
    ~msg:("function: tac_list\ninput: " ^ pp_helix in1)
    out (Dna.tac_list in1)

let tac_list_tests =
  [
    "test1" >:: tac_list_test [T; A; C; A; C; T] [C; T; T; A; C; A; C; T ];
    "test2" >:: tac_list_test [T; A; C; T; T; A; A] [A; A; C; T; A; C; T; T; A; A];
  ]*)

let acids_of_helix_test out in1 _ =
  assert_equal ~printer:pp_acid_list
    ~msg:("function: acids_of_helix\ninput: " ^ pp_helix in1)
    out (Dna.acids_of_helix in1)

let acids_of_helix_tests =
  [ (* Example test case: *)
    "acids_of_helix single codon" >:: acids_of_helix_test [ Met ] [ A; G; T;
       A; C ];
     "acids_of_helix multiple codons, stop at end codon" >:: acids_of_helix_test [Met; Val; Val] [A; A; T; A; T; A; C; C; A; A; C; A; C; A; T; T; T; T];
     "acids_of_helix multiple codons, DNA list starts with TAC, stop due to running out of codons" >:: acids_of_helix_test [Met; Gln; Asn; Lys] [T; A; C; G; T; T; T; T; A; T; T; T];
     "acids_of_helix multiple codons, stop due to running out of codons" >:: acids_of_helix_test [Met; Val; Val] [A; A; T; A; T; A; C; C; A; A; C; A; C; C; C];
     "acids_of_helix no codons" >:: acids_of_helix_test [][A; A; A; T; C; A; C; A; A; C];
     "acids_of_helix empty helix"  >:: acids_of_helix_test [][];
       ]

(*************************** all_acids_of_helix tests *************************)

let all_acids_of_helix_test out in1 _ =
  assert_equal ~printer:pp_acid_list_list
    ~msg:("function: all_acids_of_helix\ninput: " ^ pp_helix in1)
    out
    (Dna.all_acids_of_helix in1)

let all_acids_of_helix_tests =
  [ (* Example test case: *)
    (* "all_acids_of_helix [T; A; C; A; C; T]" >:: all_acids_of_helix_test [ [
       Met ] ] [ T; A; C; A; C; T ]; *) ]

(******************************************************************************)

let tests =
  "dna test suite"
  >::: complementary_helix_tests @ hamming_distance_tests
       @ decreasing_similarity_tests @ count_leaves_tests @ helix_of_tree_tests
       @ unlabel_tree_tests @ guess_parent_helix_tests
       @ add_ancestor_labels_tests @ parent_child_hamming_tests
       @ simplest_tree_tests @ find_simplest_tree_tests @ acids_of_helix_tests
       @ all_acids_of_helix_tests 

let _ = run_test_tt_main tests
