open OUnit2
open Search
open Dictionary
open DictionarySet

(*****************************************************************)
(* Examples of how to create data structures *)
(*****************************************************************)
let pp_string i = string_of_int i

let pp_string2 i = i

let rec pp_string_list l =
  match l with 
  | [] -> ""
  | h::t -> h ^ ";" ^ pp_string_list t

module Int = struct
  type t = int

  let compare x y =
    match Stdlib.compare x y with
    | x when x < 0 -> Dictionary.LT
    | 0 -> EQ
    | _ -> GT

  let to_string = string_of_int
end

(* Example: A list dictionary that maps ints to ints. *)
module D1 = ListDictionary.Make (Int) (Int)

(* Example: A set of strings, implemented with list dictionaries. *)
module S1 = DictionarySet.Make (StringKey.String) (ListDictionary.Make)

(* Example: A tree dictionary that maps case-insensitive strings to ints. *)
module D2 = TreeDictionary.Make (StringKey.CaselessString) (Int)

(* Example: A set of strings, implemented with tree dictionaries. *)
module S2 = DictionarySet.Make (StringKey.String) (TreeDictionary.Make)

(*****************************************************************)
(* Examples of how to index a directory *)
(*****************************************************************)

let data_dir_prefix = "data" ^ Filename.dir_sep
let preamble_path = data_dir_prefix ^ "preamble"

let preamble_list_idx =
  try Some (ListEngine.E.index_of_dir preamble_path) with _ -> None

let preamble_tree_idx =
  try Some (TreeEngine.E.index_of_dir preamble_path) with _ -> None

(*****************************************************************)
(* Test suite *)
(*****************************************************************)


module DictionaryTester (DM: DictionaryMaker ) = struct 
  module D = DM (Int) (Int)
  let empty_dict = D.empty
  let list_dict1 = D.insert 0 10 empty_dict
  let list_dict2 = D.insert 1 5 list_dict1 
  let list_dict3 = D.insert 5 1 (D.insert 17 10 list_dict2)
  
  let list_dict4 = D.insert 11 1 (list_dict3)
  
  (*size 7*)
  let list_dict5 = D.insert 4 1 (D.insert 6 1 list_dict4)
  let list_dict6 = D.insert 222 1 (D.insert 100 1 (D.insert 50 1 (D.insert 3 1 (D.insert 2 3 list_dict5))))

  (*[f_sam k v acc] is a function that computes the sum of
   [k] [v] and [acc]*)
let f_sam k v acc = k + v + acc

(*[f_sam2 k v acc] is a function that computes the sum of
   [k] times [v] plus [acc]*)
let f_sam2 k v acc = k * v + acc
  let tests = [
  
  ("is_empty for empty dict" >:: fun _ -> assert_equal (true) ((D.is_empty empty_dict)));
  ("is_empty for a non-empty dict" >:: fun _ -> assert_equal (false) ((D.is_empty list_dict2)));
  ("is_empty for another non-empty dict" >:: fun _ -> assert_equal (false) ((D.is_empty list_dict3)));
  ("is_empty for a third non-empty dict" >:: fun _ -> assert_equal (false) ((D.is_empty list_dict1)));
  ("is_empty for a fourth non-empty dict" >:: fun _ -> assert_equal (false) ((D.is_empty list_dict4)));
  
  (*Testing size*)
  ("size for empty dict" >:: fun _ -> assert_equal (0) ((D.size empty_dict)));
  ("size for dict of one key-value pair" >:: fun _ -> assert_equal (1) ((D.size list_dict1)));
  ("size for dict of two key-value pairs" >:: fun _ -> assert_equal (2) ((D.size list_dict2)));
  ("size for dict of multiple key-value pairs" >:: fun _ -> assert_equal (4) ((D.size list_dict3)));
  ("size for another dict of multiple key-value pairs" >:: fun _ -> assert_equal ~printer: pp_string (5) ((D.size list_dict4)));
  
  (*Testing insert*)
  ("insert 1 element into empty dict" >:: fun _ -> assert_equal (list_dict1) ((D.insert 0 10 empty_dict)));
  ("insert 1 element into dict of single key-value pair" >:: fun _ -> assert_equal (list_dict2) ((D.insert 1 5 list_dict1)));
  ("insert 2 elements into non-empty dict"  >:: fun _ -> assert_equal (list_dict3) ((D.insert 5 1 (D.insert 17 10 list_dict2))));
  ("insert 2 elements into another non-empty dict"  >:: fun _ -> assert_equal (list_dict5) ((D.insert 4 1 (D.insert 6 1 list_dict4))));
  ("insert 5 elements into another non-empty dict"  >:: fun _ -> assert_equal (list_dict6) ((D.insert 222 1 (D.insert 100 1 (D.insert 50 1 (D.insert 3 1 (D.insert 2 3 list_dict5)))))));
  
  (*Testing member*)
  ("member for empty dict" >:: fun _ -> assert_equal (false) ((D.member 1 empty_dict)));
  ("member for key not in dict of 1 key-value pair" >:: fun _ -> assert_equal (false) ((D.member 3 list_dict1)));
  ("member for key in dict of 1 key-value pair" >:: fun _ -> assert_equal (true) ((D.member 0 list_dict1)));
  ("member for key in dict of multiple key-value pair" >:: fun _ -> assert_equal (true) ((D.member 11 list_dict4)));
  ("member for key not in dict of 1 key-value pair" >:: fun _ -> assert_equal (false) ((D.member 3 list_dict2)));
  
  (*Testing find*)
  ("find key for empty dict" >:: fun _ -> assert_equal (None) ((D.find 1 empty_dict)));
  ("find existing key for dict of 1 key-value pair" >:: fun _ -> assert_equal (Some 10) ((D.find 0 list_dict1)));
  ("find existing key for dict of multiple key-value pair" >:: fun _ -> assert_equal (Some 1) ((D.find 4 list_dict5)));
  ("find non-existing key for dict of multiple key-value pair" >:: fun _ -> assert_equal (None) ((D.find 1111 list_dict4)));
  ("find existing key for another dict of multiple key-value pair" >:: fun _ -> assert_equal (Some 10) ((D.find 17 list_dict3)));
  
  (*Testing remove*)
  (* ("remove key for empty dict" >:: fun _ -> assert_equal (empty_dict) ((D.remove 1 empty_dict)));
  ("remove existing key for dict of 1 key-value pair" >:: fun _ -> assert_equal (empty_dict) ((D.remove 1 empty_dict)));
  ("remove existing key for dict of multiple key-value pair" >:: fun _ -> assert_equal (list_dict1) ((D.remove 1 list_dict2)));
  ("remove non-existing key for dict of multiple key-value pair" >:: fun _ -> assert_equal (list_dict4) ((D.remove 12039 list_dict4)));
  ("remove non-existing key for dict of single key-value pair" >:: fun _ -> assert_equal (list_dict1) ((D.remove 1 list_dict1)));
   *)
  (*Testing fold*)
  (" fold for empty dict" >:: fun _ -> assert_equal (4) ((D.fold f_sam 4 empty_dict)));
  (" fold for dict of 1 key-value pair" >:: fun _ -> assert_equal ~printer:pp_string (14) ((D.fold f_sam 4 list_dict1)));
  (" fold for dict of multiple key-value pair" >:: fun _ -> assert_equal (53) ((D.fold f_sam 4 list_dict3)));
  (" another fold for dict of 1 key-value pair" >:: fun _ -> assert_equal (4) ((D.fold f_sam2 4 list_dict1)));
  (" another fold for dict of multiple key-value pair" >:: fun _ -> assert_equal (5) ((D.fold f_sam2 0 list_dict2)));
  (" another fold for empty dict" >:: fun _ -> assert_equal (4) ((D.fold f_sam2 4 empty_dict)));
  
  (*Testing to_list*)
  (" to_list for empty dict" >:: fun _ -> assert_equal ([]) ((D.to_list empty_dict)));
  (" to_list for dict of single key-value pair" >:: fun _ -> assert_equal ([(0,10)]) ((D.to_list list_dict1)));
  (" to_list for dict of multiple key-value pairs" >:: fun _ -> assert_equal ([(0,10); (1,5)]) ((D.to_list list_dict2)));
  (" to_list for another dict of multiple key-value pairs" >:: fun _ -> assert_equal ([(0,10); (1,5); (5,1); (11,1); (17,10)]) ((D.to_list list_dict4)));
  (" to_list for another dict of multiple key-value pairs" >:: fun _ -> assert_equal ([(0,10); (1,5); (4,1); (5,1); (6,1); (11,1); (17,10)]) ((D.to_list list_dict5)));
  
  (*Testing to_string*)
  (" to_string for empty dict" >:: fun _ -> assert_equal ("{}") ((D.to_string empty_dict)));
  (" to_string for dict of 1 key value pair" >:: fun _ -> assert_equal ~printer:pp_string2 ("{0: 10}") ((D.to_string list_dict1)));
  (" to_string for dict of multiple key value pairs" >:: fun _ -> assert_equal ~printer:pp_string2 ("{0: 10, 1: 5}") ((D.to_string list_dict2)));
  (" to_string for another dict of multiple key value pairs" >:: fun _ -> assert_equal ~printer:pp_string2 ("{0: 10, 1: 5, 5: 1, 17: 10}") ((D.to_string list_dict3)));
  (" to_string for another dict of multiple key value pairs" >:: fun _ -> assert_equal ~printer:pp_string2 ("{0: 10, 1: 5, 5: 1, 11: 1, 17: 10}") ((D.to_string list_dict4)));
  
  ]

  end


  module D11 = DictionaryTester (ListDictionary.Make) 
  module T1 = DictionaryTester (TreeDictionary.Make) 

let dictionary_tests =  List.flatten[D11.tests; T1.tests]

let dict_test_suite = "dictionary test suite" >::: dictionary_tests

module DictionarySetTester (DM: DictionaryMaker) = struct

  module S1 = DictionarySet.Make (StringKey.String) (DM)
  (*[f_set1 e acc] is a function that concatenates 
   [e], space, [acc] *)
let f_set1 e acc = e ^ " " ^ acc 

    let empty_set = S1.empty
  
  let set_1 = S1.insert "hi" empty_set 
  
  let set22 = S1.insert "cake" empty_set
  
  let union_1_22 = S1.insert "cake" (S1.insert "hi" empty_set)
  
  let set2 = S1.insert "ace" (S1.insert "hello" set_1)
  
  let set3 = S1.insert "gilmore" (S1.insert "girl" set2)
  
  let diff_2_3 = S1.insert "gilmore" (S1.insert "girl" empty_set)
  
  let set4 = S1.insert "poland" set3
  
  let set5 = S1.insert "random" empty_set
  
  let union_4_5 = S1.insert "random" (S1.insert "poland" set3)
  let tests =[
  (*Testing is_empty*)
  ("is_empty for empty set" >:: fun _ -> assert_equal (true) (S1.is_empty empty_set));
  ("is_empty for set of size 1" >:: fun _ -> assert_equal (false) (S1.is_empty set_1));
  ("is_empty for set of size > 1" >:: fun _ -> assert_equal (false) (S1.is_empty set2));
  
  (*Testing size*)
  ("size for empty set" >:: fun _ -> assert_equal (0) ((S1.size empty_set)));
  ("size for set of size 1" >:: fun _ -> assert_equal (1) ((S1.size set_1)));
  ("size for set of size > 1" >:: fun _ -> assert_equal (5) ((S1.size set3)));
  ("size for another set of size > 1" >:: fun _ -> assert_equal (3) ((S1.size set2)));
  
  (*Testing insert*)
  ("insert 1 element into empty set" >:: fun _ -> assert_equal (set_1) ((S1.insert "hi" empty_set)));
  ("inserting 2 elements into set of size of 1" >:: fun _ -> assert_equal (set2) ((S1.insert "ace" (S1.insert "hello" set_1))));
  ("inserting elements into set of size > 1" >:: fun _ -> assert_equal (set3) ((S1.insert "gilmore" (S1.insert "girl" set2))));
  ("inserting 1 element into another set of size > 1" >:: fun _ -> assert_equal (set4) (S1.insert "poland" set3));
  
  (*Testing member*)
  ("member for empty set" >:: fun _ -> assert_equal (false) ((S1.member "hi" empty_set)));
  ("existing member for set of size 1" >:: fun _ -> assert_equal (true) ((S1.member "hi" set_1)));
  ("non-existing member for set of size 1" >:: fun _ -> assert_equal (false) ((S1.member "orange" set_1)));
  ("existing member for set of size > 1" >:: fun _ -> assert_equal (true) ((S1.member "girl" set3)));
  ("non-existing member for set of size > 1" >:: fun _ -> assert_equal (false) ((S1.member "soap" set3)));
  
  (*Testing remove*)
  (* ("remove for empty set" >:: fun _ -> assert_equal (empty_set) ((S1.remove "hi" empty_set)));
  ("remove existing member for set of size 1" >:: fun _ -> assert_equal (empty_set) ((S1.remove "hi" set_1)));
  ("remove non-existing member for set of size 1" >:: fun _ -> assert_equal (set_1) ((S1.remove "hello" set_1)));
  ("remove 2 existing members for set of size> 1" >:: fun _ -> assert_equal (set_1) ((S1.remove "hello" (S1.remove "ace" set2))));
  ("remove non-existing member for set of size> 1" >:: fun _ -> assert_equal (set2) ((S1.remove "test" set2)));
   *)

  (*Testing union*)
  ("union 2 empty sets" >:: fun _ -> assert_equal (empty_set) ((S1.union empty_set empty_set)));
  ("union empty set with set of size 1" >:: fun _ -> assert_equal (set_1) ((S1.union empty_set set_1)));
  ("union empty set with set of size > 1" >:: fun _ -> assert_equal (set2) ((S1.union empty_set set2)));
  ("union 2 sets with overlapping elements" >:: fun _ -> assert_equal (set2) ( (S1.union set_1 set2)));
  ("union 2 sets with no overlapping elements" >:: fun _ -> assert_equal  ~printer:pp_string2 (S1.to_string union_1_22) (S1.to_string (S1.union set_1 set22)));
  ("union another 2 sets with overlapping elements" >:: fun _ -> assert_equal  (S1.to_string (set3)) (S1.to_string (S1.union set3 set2)));
  ("union another 2 sets with no overlapping elements" >:: fun _ -> assert_equal  ~printer:pp_string2 (S1.to_string (union_4_5)) (S1.to_string (S1.union set4 set5)));
  
  (*Testing intersect*)
  ("intersect 2 empty sets" >:: fun _ -> assert_equal (empty_set) ((S1.intersect empty_set empty_set)));
  ("intersect empty set with set of size 1" >:: fun _ -> assert_equal (empty_set) ((S1.intersect empty_set set_1)));
  ("intersect empty set with set of size > 1" >:: fun _ -> assert_equal (empty_set) ((S1.intersect empty_set set2)));
  ("intersect 2 sets with overlapping elements" >:: fun _ -> assert_equal (S1.to_string set_1) ( S1.to_string (S1.intersect set_1 set2)));
  ("intersect 2 sets with non-overlapping elements" >:: fun _ -> assert_equal (S1.to_string empty_set) (S1.to_string (S1.intersect set_1 set22)));
  ("intersect another 2 sets with overlapping elements" >:: fun _ -> assert_equal (S1.to_string set3) (S1.to_string (S1.intersect set3 set4)));
  ("intersect another 2 sets with non-overlapping elements" >:: fun _ -> assert_equal (S1.to_string empty_set) (S1.to_string (S1.intersect set5 set4)));
  
  
  (*Testing difference*)
  ("difference of 2 empty sets" >:: fun _ -> assert_equal (empty_set) ((S1.difference empty_set empty_set)));
  ("difference between empty set and non-empty set" >:: fun _ -> assert_equal (empty_set) ((S1.difference empty_set set2)));
  ("difference between non-empty set and empty-set" >:: fun _ -> assert_equal (S1.to_string set2) (S1.to_string (S1.difference set2 empty_set)));
  ("difference between 2 non-empty-sets with all overlapping elements" >:: fun _ -> assert_equal (S1.to_string empty_set) (S1.to_string (S1.difference set2 set3)));
  ("difference between 2 non-empty-sets with partially overlapping elements" >:: fun _ -> assert_equal (S1.to_string diff_2_3) (S1.to_string (S1.difference set3 set2)));
  ("difference between 2 non-empty-sets with no overlapping elements" >:: fun _ -> assert_equal (S1.to_string set_1) (S1.to_string (S1.difference set_1 set22)));
  
  
  (*Testing fold*)
  (" fold for empty set" >:: fun _ -> assert_equal ~printer:pp_string2 ("a") ((S1.fold f_set1 "a" empty_set)));
  (" fold for set of size 1" >:: fun _ -> assert_equal ~printer:pp_string2("hi a") ((S1.fold f_set1 "a" set_1)));
  (" fold for set of size > 1" >:: fun _ -> assert_equal ~printer:pp_string2("hi hello ace a") ((S1.fold f_set1 "a" set2)));
  (" fold for set of size > 1, different initial accumulator value" >:: fun _ -> assert_equal ~printer:pp_string2("hi hello ace ") ((S1.fold f_set1 "" set2)));
  (" fold for another set of size > 1" >:: fun _ -> assert_equal ~printer:pp_string2("hi hello girl gilmore ace acc") ((S1.fold f_set1 "acc" set3)));
  
  (*Testing to_list*)
  (" to_list for empty set" >:: fun _ -> assert_equal ([]) ((S1.to_list empty_set)));
  (" to_list for set of size 1" >:: fun _ -> assert_equal (["hi"]) ((S1.to_list set_1)));
  (" to_list for set of size > 1" >:: fun _ -> assert_equal (["ace"; "hello"; "hi"]) ((S1.to_list set2)));
  (" to_list for another set of size > 1" >:: fun _ -> assert_equal (["ace"; "gilmore"; "girl"; "hello"; "hi"; "poland"]) ((S1.to_list set4)));
  
  (*Testing to_string*)
  (" to_list for empty set" >:: fun _ -> assert_equal ("{}") ((S1.to_string empty_set)));
  (" to_list for set of size 1" >:: fun _ -> assert_equal ~printer:pp_string2 ("{" ^ "\"" ^ "hi" ^ "\"" ^ "}") ((S1.to_string set_1)));
  (" to_list for set of size > 1" >:: fun _ -> assert_equal ~printer:pp_string2 ("{" ^ "\"" ^ "ace" ^ "\"" ^ ";" ^ "\"" ^ "hello" ^ "\"" ^ ";" ^ "\"" ^ "hi" ^ "\"" ^ "}") ((S1.to_string set2)));
  (" to_list for another set of size > 1" >:: fun _ -> assert_equal ("{" ^ "\"" ^ "ace" ^ "\"" ^ ";" ^ "\"" ^ "gilmore" ^ "\"" ^ ";"^ "\"" ^ "girl" ^ "\"" ^ ";" ^ "\"" ^ "hello" ^ "\"" ^ ";" ^ "\"" ^ "hi" ^ "\"" ^ ";" ^ "\"" ^ "poland" ^ "\"" ^ "}")
   ((S1.to_string set4)));
  ]
  end
  

  module S12 = DictionarySetTester  (ListDictionary.Make) 
  module S22= DictionarySetTester (TreeDictionary.Make) 

let dictionary_set_tests =  List.flatten[S12.tests; S22.tests]

let dict_set_test_suite = "dictionary test suite" >::: dictionary_set_tests
  
module EngineTester (E: Engine.E) = struct 
  let data_dir_prefix = "data" ^ Filename.dir_sep
  let alice_path = data_dir_prefix ^ "alice"

  let alice_idx =
    try Some (E.index_of_dir alice_path) with _ -> None

  let match_idx x = 
    match x with 
    | None -> failwith ("Wrong")
    | Some c -> c
  
  let data_dir_prefix = "data" ^ Filename.dir_sep
  let preamble_path = data_dir_prefix ^ "preamble"

  let preamble_idx =
    try Some (E.index_of_dir preamble_path) with _ -> None

  
  let or1 = ["we"; "the"; "people"]
  let and1 = ["we"; "the"; "people"]

  let and2 = ["establish"]
  let or2 = ["establish"; "provide"]
  let or3 = ["apples"; "oranges"]
  let not1 = ["alice"]
  let not2 =["provide"; "for"; "a"]
  let not3 = ["apples"; "oranges"]

  let tests = [
    (" words for alice" >:: fun _ -> assert_equal (3278) (List.length (E.words (match_idx alice_idx))));
    (" words for preamble" >:: fun _ -> assert_equal ~printer: pp_string (38) (List.length (E.words (match_idx preamble_idx))));
    (" to_list for alice" >:: fun _ -> assert_equal (3278) (List.length (E.to_list (match_idx alice_idx))));
    (" to_list for preamble" >:: fun _ -> assert_equal ~printer: pp_string (38) (List.length (E.to_list (match_idx preamble_idx))));
    (* (" or_not for preamble" >:: fun _ -> assert_equal ~printer: pp_string_list (["prefix.txt";"whole.txt"]) ((E.or_not (match_idx preamble_idx) or1 not1)));
    (" or_not for preamble" >:: fun _ -> assert_equal ~printer: pp_string (1) (List.length (E.or_not (match_idx preamble_idx) or1 not2)));
    (" or_not for preamble" >:: fun _ -> assert_equal ~printer: pp_string_list (["prefix.txt";"whole.txt"]) ((E.or_not (match_idx preamble_idx) or1 not3)));
    (" or_not for preamble" >:: fun _ -> assert_equal ~printer: pp_string_list (["prefix.txt";"whole.txt"]) ((E.or_not (match_idx preamble_idx) or1 not3)));  *)
    (* (" and_not for preamble" >:: fun _ -> assert_equal ~printer: pp_string_list (["prefix.txt";"whole.txt"]) ((E.and_not (match_idx preamble_idx) and1 not1))); *)
    (* (" and_not for preamble" >:: fun _ -> assert_equal ~printer: pp_string_list (["prefix.txt"]) ((E.and_not (match_idx preamble_idx) and1 not2))); *)
    (* (" and_not for preamble" >:: fun _ -> assert_equal ~printer: pp_string_list ([]) ((E.and_not (match_idx preamble_idx) and2 not2))); 
    (" and_not for preamble" >:: fun _ -> assert_equal ~printer: pp_string_list (["whole.txt"]) ((E.and_not (match_idx preamble_idx) and2 not3)));  *)

    ]
  end

  module ListEngineTest = EngineTester (ListEngine.E)

  module TreeEngineTest = EngineTester(TreeEngine.E)
  let engine_tests = List.flatten [ListEngineTest.tests; TreeEngineTest.tests;]

  let engine_suite = "engine test suite" >::: engine_tests
  
let suite = "search test suite" >::: [
(***ENGINE TESTS****)

]

let dictt = run_test_tt_main  dict_test_suite
let dict_set = run_test_tt_main dict_set_test_suite
(* let suite_run = run_test_tt_main suite *)
let engine_run = run_test_tt_main engine_suite