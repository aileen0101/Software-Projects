open Dictionary

module Make =
functor
  (K : KeySig)
  (V : ValueSig)
  ->
  struct
    module Key = K
    module Value = V

    type key = K.t
    type value = V.t

    type color = 
    | Red 
    | Blk
  (** AF: [Leaf] represents the empty dictionary. 
  [Node (c, l, (k,v), r)]
      represents the dictionary containing the key-value binding (k,v), 
      as well as all the bindings of
      the dictionaries in [l] and [r]. Subtrees [l] and [r] also have this 
      property.
      RI: The BST invariant, the local RB tree invariants
       and global RB tree invariants hold.*)

    type t = 
    | Leaf 
    | Node of (color * t * (key*value) * t)

    (*[bst_check t] checks that the tree [t] satisfies the BST invariants*)
        (*[bst_check t] checks that the tree [t] satisfies the BST invariants*)
        let rec bst_check t = 
          match t with 
          | Leaf -> true 
          | Node (c, Leaf, (k,v), Leaf) -> true
          | Node (c, l, (k, _), r) -> 
            let left_bst = 
              match l with
              | Leaf -> true
              | Node (_, _, (lk, _), _) -> Key.compare lk k = LT && bst_check l
            in
            let right_bst =
              match r with
              | Leaf -> true
              | Node (_, _, (rk, _), _) -> Key.compare rk k = GT && bst_check r
            in
            left_bst && right_bst
            [@@coverage off]
    (*[local_check t] checks that the local RB tree invariant is satisfied*)
    let rec local_check t =
      match t with
      | Leaf -> true
      | Node (Blk, l, _, r) -> local_check l && local_check r
      | Node (Red, l, _, r) ->
          let left_check =
            match l with
            | Leaf -> true
            | Node (c1, _, _, _) -> c1 = Blk && local_check l
          in
          let right_check =
            match r with
            | Leaf -> true
            | Node (c2, _, _, _) -> c2 = Blk && local_check r
          in
          left_check && right_check
          [@@coverage off]
    (*[count_subtree t] counts the number of black nodes in subtree [t]*)
    let rec count_subtree t = 
      match t with 
      | Leaf -> 1
      | Node(Blk, l, _, _) -> 1 + count_subtree l
      | Node(_, l, _, _) -> count_subtree l
      [@@coverage off]

    (*[global_check t] checks that the global RB tree invariant is satisfied**)
    let rec global_check t =
      match t with 
      | Leaf -> true 
      | Node(_, l, _, r) -> 
        count_subtree l = count_subtree r && global_check l && global_check r
        [@@coverage off]
    let debug = false
    let rep_ok d = 
      
      if debug 
      then if
      (bst_check d) && (local_check d) && (global_check d)
      then d else failwith "RI" 
      else d
    
    [@@coverage off]
    let empty = Leaf

    let is_empty d =
      match rep_ok d with 
      | Leaf -> true 
      | Node(c, l, v, r) -> false

    let rec size d = 
      match (rep_ok d) with 
      | Leaf -> 0 
      | Node(c, Leaf, (k,v), Leaf) -> 1
      | Node(c, l, (k,v),r)->  1 + size l + size r


        (** [balance (c, l, v, r)] implements the four possible rotations that
      could be necessary to balance a node and restore the RI clause
      about Red nodes. Efficiency: O(1) *)
  let balance = function
  | Blk, Node (Red, Node (Red, a, x, b), y, c), z, d
  | Blk, Node (Red, a, x, Node (Red, b, y, c)), z, d
  | Blk, a, x, Node (Red, Node (Red, b, y, c), z, d)
  | Blk, a, x, Node (Red, b, y, Node (Red, c, z, d)) ->
      Node (Red, Node (Blk, a, x, b), y, Node (Blk, c, z, d))
  | t -> Node t
  
      let rec insert_help k v = function
      | Leaf -> Node (Red, Leaf, (k,v), Leaf) 
      | Node (c, l, (k1, v1), r) as n ->
          if Key.compare k k1 = LT then balance (c, insert_help k v l, (k1, v1), r)
          else if Key.compare k k1 = GT then balance (c, l, (k1, v1), insert_help k v r)
          else n

    let insert k v d =
      match insert_help k v d with
      | Leaf ->
          failwith "impossible"
      | Node (_, l, (k1,v1), r) -> Node (Blk, l, (k1,v1), r)
    let remove k d = 
      raise (Failure "Unimplemented: TreeDictionary.Make.remove")

    let rec find k d = 
      match d with 
       | Leaf -> None 
       | Node(c, l, (k1, v), r) ->
        if Key.compare k k1 = LT then find k l else if Key.compare k k1 = GT
          then find k r else Some v

    let rec member k d = 
      match d with 
       | Leaf -> false 
       | Node(c, l, (k1, v), r) ->
        if Key.compare k k1 = LT then member k l else if Key.compare k k1 = GT 
          then member k r else true
    let rec to_list d = 
      match (rep_ok d) with
       | Leaf -> []
       | Node(c, Leaf, (k,v), Leaf) -> [(k,v)]
       | Node(c, l, (k, v), r) -> (to_list l) @ [(k,v)] @ to_list r
    let rec fold f acc d = 
      let d_lst = to_list (rep_ok d) in 
      let rec fold2 f acc d_lst = 
        match d_lst with 
        | [] -> acc 
        | (k,v)::t  -> let acc_ = f k v acc in fold2 f acc_ t 
      in fold2 f acc d_lst
    
    
    (*[string_key k] returns the string representation of a 
       given key [k]*)
       let string_key k= 
       Key.to_string k
 
     (*[string_value v] returns the string representation of a 
        given value [v]*)
     let string_value v = Value.to_string v
     
    let to_string d =
      let d_lst = to_list (rep_ok d) in 
      Util.string_of_bindings (string_key) (string_value) (d_lst)
  end
