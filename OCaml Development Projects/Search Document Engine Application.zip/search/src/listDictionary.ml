open Dictionary

module Make : DictionaryMaker =
functor
  (K : KeySig)
  (V : ValueSig)
  ->
  struct
    module Key = K
    module Value = V

    type key = K.t
    type value = V.t

    type t = (key * value) list 
    (** AF: [(k1, v1); (k2, v2); ... ;(kn, vn)] represents 
    the map {k1:v1, k2:v2, ... kn:vn}. 
    The empty list represents the empty map.
    RI: The list must not contain duplicates. *)


    (*[convert_compare f k1 k2] converts the outputs of applying
       a compare function [f] on [k1] and [k2] 
       from an order type to an int.*)
       let convert_compare f k1 k2 = 
        match f k1 k2 with 
        | LT -> -1 
        | EQ -> 0 
        | GT -> 1
  
      (*[sort_keys k] takes a list of keys [k] and 
         sorts it.*)
      let sort_keys k = k |> List.sort_uniq (convert_compare Key.compare)


    (*[get_keys d] returns a list of keys from the given dictionary [d]*)
    let rec get_keys d = 
      match (d) with 
      | [] -> []
      | (k,_):: t -> k :: get_keys t

    (*Set global variable debug so that functions can turn on and off rep_ok*)
    (* let debug = false *)
    let rep_ok d = 
      d
      [@@coverage off]
      (*commented out implementation here: *)
      (* let curr_length = List.length d in 
      let k_lst = get_keys d in let s_k_lst = sort_keys k_lst in
      let uniq_length = List.length s_k_lst 
    in if uniq_length = curr_length then d else failwith "RI"  *)
  
      
    let empty = []

    let is_empty d =
      if List.length (rep_ok d) = 0 then true else false

    let size d = List.length (rep_ok d)

    let replace_key k v d = 
      (k,v) :: (List.remove_assoc k d)
    let insert k v d =
      if List.mem_assoc k (rep_ok d) = true then replace_key k v (rep_ok d)
       else (k,v)::(rep_ok d)
    let remove k d = 
      if List.mem_assoc k (rep_ok d) = true then List.remove_assoc k (rep_ok d) else (rep_ok d)
    let find k d = if List.mem_assoc k (rep_ok d) then List.assoc_opt k (rep_ok d) else None
    let member k d = if List.mem_assoc k (rep_ok d) then true else false


    (*Given a list of keys [list] and dictionary [d], 
       [dict_return k_lst d] returns a copy of the dictionary [d] 
    according to the order of the keys in [k_lst].  *)
    let rec dict_return k_lst d = 
      match k_lst with 
      | [] -> []
      | h::t -> (h, List.assoc h (rep_ok d)) :: (dict_return t (rep_ok d))

     let to_list d = 
      let key_list = get_keys (rep_ok d) 
    in let sorted_keys = sort_keys key_list 
    in dict_return sorted_keys (rep_ok d)

    let rec fold f init d = 
      match (rep_ok d) with 
      | []-> init 
      | (k,v)::t -> let acc = f k v init in fold f acc t

    (*[string_key k] returns the string representation of a 
       given key [k]*)
    let string_key k= 
      Key.to_string k

    (*[string_value v] returns the string representation of a 
       given value [v]*)
    let string_value v = Value.to_string v

    let to_string d = 
      let sorted_d = to_list (rep_ok d) in
      Util.string_of_bindings (string_key) (string_value) (sorted_d)

  end
  
