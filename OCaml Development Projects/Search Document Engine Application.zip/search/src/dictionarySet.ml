open Dictionary

module type ElementSig = sig
  type t

  include Dictionary.KeySig with type t := t
end

module type Set = sig
  module Elt : ElementSig

  type elt = Elt.t
  type t

  val empty : t
  val is_empty : t -> bool
  val size : t -> int
  val insert : elt -> t -> t
  val member : elt -> t -> bool
  val remove : elt -> t -> t
  val union : t -> t -> t
  val intersect : t -> t -> t
  val difference : t -> t -> t
  val fold : (elt -> 'acc -> 'acc) -> 'acc -> t -> 'acc
  val to_list : t -> elt list

  include Stringable with type t := t
end

module Make =
functor
  (E : ElementSig)
  (DM : DictionaryMaker)
  ->
  struct
    module Elt = E

    type elt = Elt.t

    (*module V represents the value module of our dictionary*)
    module V = struct 
      type t = unit 
      
      let to_string s = "()"
    end

    (*Need to pass in Key Module and Value Module to DM*)
    module D = DM (Elt) (V)

    type t = D.t
    (** AF: {k1:v1, k2:v2, ... kn:vn} represents 
    the set {k1, k2, ... kn}. 
    The empty dictionary represents the empty set.
    RI: The map must not contain duplicate keys. *)

      (*[convert_compare f k1 k2] converts the outputs of applying
       a compare function [f] on [k1] and [k2] 
       from an order type to an int.*)
       let convert_compare f k1 k2 = 
        match f k1 k2 with 
        | LT -> -1 
        | EQ -> 0 
        | GT -> 1
      
        (*[sort_keys k] takes a list of keys [k] and 
         sorts it.*)
      let sort_keys k = k |> List.sort_uniq (convert_compare Elt.compare)

    (*[get_keys s] returns a list of keys from the list rep of dictionary set [s]*)
    let rec get_keys s_lst = 
      match s_lst with 
        | [] -> []
        | (k,_):: t -> k :: get_keys t

    let rep_ok s = s
      (*commented out rep_ok impl*)
    (* let s_lst = D.to_list s 
    in let curr_length= List.length (s_lst) in 
    let k_lst = get_keys s_lst in let s_k_lst = sort_keys k_lst in
    let uniq_length =List.length s_k_lst in 
    if uniq_length = curr_length then s else failwith "RI"  *)

    let empty = D.empty

    let is_empty s =
      D.is_empty (rep_ok s)

    let size s = D.size (rep_ok s)

    let insert_exists x s = 
      let s_keys = get_keys (D.to_list s) in
      let sorted_k = sort_keys s_keys in
      let rec new_lst x sorted_k = 
        match sorted_k with 
        | [] -> []
        | h::t -> if h = x then t else h:: (new_lst x t)
      in
      let updated= new_lst x sorted_k in 
      let s3 = D.empty in
      let rec convert updated = 
        match updated with 
        | [] -> s3
          | h::t -> D.insert h () (convert t)
      in convert updated

    let insert x s = if D.member x (rep_ok s) then
    insert_exists x s else D.insert x () (rep_ok s)
    let member x s = D.member x (rep_ok s)
    let remove x s = D.remove x (rep_ok s)
    

      (*[convert_compare f k1 k2] converts the outputs of applying
       a compare function [f] on [k1] and [k2] 
       from an order type to an int.*)
    let convert_compare f k1 k2 = 
      match f k1 k2 with 
      | LT -> -1 
      | EQ -> 0 
      | GT -> 1
    
      (*[sort_keys k] takes a list of keys [k] and 
       sorts it.*)
    let sort_keys k = k |> List.sort_uniq (convert_compare Elt.compare)
      
    let fold f init s = 
      let s_lst = get_keys (D.to_list (rep_ok s)) in 
      let sorted_lst = sort_keys s_lst in 
      let rec fold2 f init s_lst = 
        match s_lst with 
        | [] -> init 
        | h::t -> let acc = f h init in fold2 f acc t 
      in fold2 f init sorted_lst

    let union s1 s2 =
      let lst_of_lsts = [get_keys (D.to_list (rep_ok s1)) ; get_keys (D.to_list (rep_ok s2))]in
      let comb_lst = List.concat (lst_of_lsts) in 
      let sorted_lst = sort_keys comb_lst in 
        let rec make_map l = 
          match l with 
          | [] -> D.empty
          | h::t -> D.insert h () (make_map t)
      in rep_ok (make_map sorted_lst)

    let intersect s1 s2 =
      let s1_keys = get_keys (D.to_list (rep_ok s1)) in 
      let s3 = D.empty in 
      let rec intersect2 s1_k s2 s3 = 
        match s1_k with 
        | [] -> (rep_ok s3) 
        | h :: t-> if D.member h (s2)
          then let acc = D.insert h () (rep_ok s3)
          in rep_ok (intersect2 t (rep_ok s2) acc) else 
            rep_ok (intersect2 t (rep_ok s2) (rep_ok s3))
      in rep_ok (intersect2 s1_keys s2 s3)

    let difference s1 s2 =
      let intersection = intersect (rep_ok s1) (rep_ok s2) in 
      let s1_keys = get_keys (D.to_list s1) in 
      let s3 = D.empty in 
      let rec diff2 s1_k i s3 = 
        match s1_k with 
        | [] -> (rep_ok s3)
        | h::t -> if D.member h (rep_ok i) then rep_ok (diff2 t (rep_ok i) (rep_ok s3)) 
        else let acc = D.insert h () (rep_ok s3) in rep_ok (diff2 t (rep_ok i) acc )
      in rep_ok (diff2 s1_keys intersection s3) 
      

    let to_list s = 
      let s_lst = get_keys (D.to_list (rep_ok s)) in 
      sort_keys s_lst  

    (*[string_key k] returns the string representation of a 
       given key [k]*)
    let string_key k= 
    Elt.to_string k

    let to_string s = 
      let s_lst = get_keys (D.to_list (rep_ok s)) in 
      let sorted_lst = sort_keys s_lst in 
      Util.string_of_list ~open_delim:"{" ~close_delim:"}" ~sep:";" string_key sorted_lst
  end
